function P = solve_gwf_v2(k, F)
    [K1,K2] = size(k);
    assert(K1==K2, 'k must be KxK');
    K = K1;
    assert(all(size(F)==[K K]), 'F must be KxK');
    h = 1/K; % cell width
    N = K*K; % number of unknowns
    eps_d = 1e-30;

    % Face transmissibilities (harmonic means)
    % East-West faces
    kEW = 2 .* k(:,1:K-1) .* k(:,2:K) ./ (k(:,1:K-1) + k(:,2:K) + eps_d);
    % North-South faces
    kNS = 2 .* k(1:K-1,:) .* k(2:K,:) ./ (k(1:K-1,:) + k(2:K,:) + eps_d);

    % 5-point stencil
    est_nnz = 5*N;
    I = zeros(est_nnz,1);
    J = zeros(est_nnz,1);
    V = zeros(est_nnz,1);
    ptr = 0;

    idx = reshape(1:N, K, K);

    % sum of neighbor transmissibilities + boundary T
    D = zeros(K,K);
    % add interior face contributions
    D(:,1:K-1) = D(:,1:K-1) + kEW;
    D(:,2:K) = D(:,2:K) + kEW;
    D(1:K-1,:) = D(1:K-1,:) + kNS;
    D(2:K,:) = D(2:K,:) + kNS;

    % Dirichlet boundary: T_b = 2*k_face (distance = h/2, area = h; T = k*A/d = 2k)
    D(:,1) = D(:,1) + 2*k(:,1);
    D(:,K) = D(:,K) + 2*k(:,K);
    D(1,:) = D(1,:) + 2*k(1,:);
    D(K,:) = D(K,:) + 2*k(K,:);

    % Center (diagonal)
    ii = idx(:);
    ptr = ptr + numel(ii);
    I(ptr-numel(ii)+1:ptr) = ii;
    J(ptr-numel(ii)+1:ptr) = ii;
    V(ptr-numel(ii)+1:ptr) = D(:);

    % East-West off-diagonals (symmetric)
    rowsEW = idx(:,1:K-1);
    colsEW = idx(:,2:K);
    valEW = -kEW;
    m = numel(rowsEW);
    I(ptr+1:ptr+m) = rowsEW(:);
    J(ptr+1:ptr+m) = colsEW(:);
    V(ptr+1:ptr+m) = valEW(:);
    ptr = ptr + m;
    I(ptr+1:ptr+m) = colsEW(:);
    J(ptr+1:ptr+m) = rowsEW(:);
    V(ptr+1:ptr+m) = valEW(:);
    ptr = ptr + m;

    % North-South off-diagonals (symmetric)
    rowsNS = idx(1:K-1,:);
    colsNS = idx(2:K,:);
    valNS = -kNS;
    m = numel(rowsNS);
    I(ptr+1:ptr+m) = rowsNS(:);
    J(ptr+1:ptr+m) = colsNS(:);
    V(ptr+1:ptr+m) = valNS(:);
    ptr = ptr + m;
    I(ptr+1:ptr+m) = colsNS(:);
    J(ptr+1:ptr+m) = rowsNS(:);
    V(ptr+1:ptr+m) = valNS(:);
    ptr = ptr + m;

    % Assemble (trim unused prealloc)
    I = I(1:ptr);
    J = J(1:ptr);
    V = V(1:ptr);
    A = sparse(I,J,V,N,N);

    % RHS integrates source over the cell: F * h^2
    b = (F(:) * h^2);

    % Solve
    P = reshape(A \ b, K, K);
end